#!/usr/bin/env python

# RSS-Planet 1.0
#
# By
# Martin C. Doege, 2005-07-27/2

import os, re, math, time, urllib2
import rssparser

delay     = 600		# update interval (seconds)
mindist   = 2.		# minimum distance for stories (degrees); set to zero to show all stories
maxlen    = 35		# maximum number of characters in story title
timestamp = True	# show time of last update
start_xplanet = True	# Launch xplanet on startup
verbose   = False	# print out activity

feeds = ("http://rss.cnn.com/rss/cnn_topstories.rss",
	 "http://rss.news.yahoo.com/rss/topstories",
	 "http://rss.cnn.com/rss/cnn_world.rss",
	 "http://rss.news.yahoo.com/rss/world" )

#	 "http://www.washingtonpost.com/wp-dyn/rss/world/index.xml"

#################################################################################################

caps = (("Washington",	"Washington DC"),
	("London",	"London UK"),
	("Berlin",	"Berlin Germany"),
	("Paris",	"Paris France"),
	("United Nations", "New York")
)


def printout(x):
	if verbose:
		print x

def get_rss(u):
	o = []
	try:
		result = rssparser.parse(u)
		for item in result['items']:
			title = item.get('title', u"(none)")
			url  = item.get('link', u"(none)")
			o.append((url, title.encode('ascii', 'replace')))
		return o
	except:
		return []
		
def get_story(u):
	html = ""
	try:
		f = urllib2.urlopen(u)
		for x in f.readlines():
			html += x.strip() + ' * '
		return re.sub("<.*?>", "", html)
	except: return ""
	
def _start_word(w):
	try:	return w.upper() == w and w[0].isalpha() and w[1] != '.'
	except: return False

def _caps_not_in_title(w, t):
	if w.upper() == w:
		return w not in t
	else: return False

def guess_by_caps(t, title):
	o = ""
	addword = False
	count = 0
	for w in t.split():
		count += 1
		if _start_word(w) and _caps_not_in_title(w, title) and not addword:
			addword = True
			count = 0
			o = ""
		if w == '--' or w == '-' and addword:
			addword = False
			return o.strip()
		if count > 4 or w == '*':
			addword = False
			o = ""
		if addword and w[0] != '(':
			o += w + ' '
	return o.strip()
	
def guess_by_in(t):
	months = ("January", "February", "March", "April", "May", "June",
			"July", "August", "September", "October", "November", "December")
	found = False
	for w in t.split():
		if found:
			if w[0].isupper() and w not in months:
				return w
			else: found = False
		if w.lower() == 'in':
			found = True

def text2place(t, title):
	c = guess_by_caps(t, title) or guess_by_in(t) or ""
	c = c.replace(',', ' ').strip()
	for x, y in caps:
		if c.lower() == x.lower():
			c = y
	q = ""
	for x in c.split():
		try: q += abbrev[x.lower()] + ' '
		except: q += x + ' '
	return q.strip()

def num2blank(x):
	if x.isalpha(): return x
	else: return ' '
	
def place2coord(p):
	p = [num2blank(x) for x in p if x.isalnum() or x == ' ']
	p = reduce(lambda x, y: x + y, p)

	maxscore = 0
	o = ""
	for line in cities:
		l = line.lower()
		score = 0
		p2 = [x for x in p.split() if len(x) > 1]
		for x, s in zip(p2, range(len(p2), 0, -1)):
			for w in l.split():
				w2 = w.strip()
				if x.lower() == w2:
					score += s
					if score > maxscore:
						o = l
						maxscore = score
	x = o.split(':')
	lat = float(x[3]) + float(x[4]) / 60.
	lon = float(x[7]) + float(x[8]) / 60.
	if x[6].strip()  == 's': lat = -lat
	if x[10].strip() == 'w': lon = -lon
	return lat, lon

def getdist(a, b):
	return math.sqrt( (a[0] - b[0]) * (a[0] - b[0]) +
			  (a[1] - b[1]) * (a[1] - b[1])  )

def display_item(c, t, u):
	global items
	dist = 400.
	if mindist:
		for x in items:
			d = getdist(x[0], c)
			if d < dist: dist = d
		if dist < mindist:
			printout("(dropped)")
			return
	items += (c, t, u),

def show_in_xplanet():
	if not items: return
	f = open("rssitems", 'w')
	for c, t, u in items:
		if len(t) > maxlen:
			t = t[:maxlen] + "..."
		t = t.replace('"', "'")
		f.write('%f %f "%s" color=Yellow\n' % (c[0], c[1], t))
	if timestamp:
		tl = time.strftime("%Y-%m-%d %H:%M", time.localtime(time.time()))
		f.write('%f %f "Last updated %s" color=Green image=none align=above\n' % (-70, 0, tl))
	f.close()


# launch xplanet:
if start_xplanet:
	os.system("killall xplanet 2> /dev/null")
	#os.system("xplanet -wait 10 -fork -window -geometry 1024x768 -projection rectangular -config ./default")
	os.system("xplanet -wait 200  -projection rectangular -config ./default &")

# read cities database:
f = open("Cities.dat", 'r')
cities = f.readlines()
f.close()

# read abbreviations:
f = open("abbrev.dat", 'r')
abbrev = {}
for x in f.readlines():
	a, b = x.split(':')
	abbrev[b.lower().strip()] = a.strip()
f.close()

while True:
	items = []
	for f in feeds:
		printout(60 * '-')
		news = get_rss(f)			# returns a list of URLs and story titles
		for url, title in news:
			try:
				text  = get_story(url)		# gets text for story
				place = text2place(text, title)	# find out the place name
				printout("%s -> %s" %(place, title))
				coord = place2coord(place)
				printout(coord)
				display_item(coord, title, url)	# remember for displaying
			except:
				printout("Warning, malformed story.")
	show_in_xplanet()		# show all items in xplanet
	time.sleep(delay)
